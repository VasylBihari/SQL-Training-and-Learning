# SQL Advent Calendar 2024

This repository contains my solutions to Interview Master's 24-day SQL Advent Calendar challenge.

## About the Challenge

The SQL Advent Calendar is a festive coding challenge featuring 24 days of SQL problems, hosted by Interview Master.

Learn more at [interviewmaster.ai/advent](https://www.interviewmaster.ai/advent)