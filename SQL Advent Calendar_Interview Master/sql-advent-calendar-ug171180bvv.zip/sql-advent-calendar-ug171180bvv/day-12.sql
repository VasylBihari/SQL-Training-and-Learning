-- SQL Advent Calendar - Day 12
-- Title: North Pole Network Most Active Users
-- Difficulty: hard
--
-- Question:
-- The North Pole Network wants to see who's the most active in the holiday chat each day. Write a query to count how many messages each user sent, then find the most active user(s) each day. If multiple users tie for first place, return all of them.
--
-- The North Pole Network wants to see who's the most active in the holiday chat each day. Write a query to count how many messages each user sent, then find the most active user(s) each day. If multiple users tie for first place, return all of them.
--

-- Table Schema:
-- Table: npn_users
--   user_id: INT
--   user_name: VARCHAR
--
-- Table: npn_messages
--   message_id: INT
--   sender_id: INT
--   sent_at: TIMESTAMP
--

-- My Solution:

WITH rank_table AS (SELECT
  u.user_id AS user_id,
  m.sent_at::DATE AS date_sent,
  COUNT(message_id),
  DENSE_RANK()OVER(PARTITION BY m.sent_at::DATE ORDER BY COUNT(message_id) DESC) AS rank_count
FROM npn_users u
INNER JOIN npn_messages m ON u.user_id=m.sender_id
GROUP BY u.user_id, date_sent)
SELECT 
  user_id,
  date_sent
FROM rank_table
WHERE rank_count = 1
